#include <experimental/filesystem>

int main() {
    std::experimental::filesystem::path path("/root");
    (void)path;
}
