# s2-geometry-library
