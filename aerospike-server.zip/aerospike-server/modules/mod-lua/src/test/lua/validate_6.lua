
function a(b)
    function c.d(e)
    end
end
