
function foo()
    var : bar
end